/*!
 * chartjs-chart-treemap v2.3.0
 * https://chartjs-chart-treemap.pages.dev/
 * (c) 2023 Jukka Kurkela
 * Released under the MIT license
 */
! function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? e(exports, require("chart.js"), require("chart.js/helpers")) : "function" == typeof define && define.amd ? define(["exports", "chart.js", "chart.js/helpers"], e) : e((t = "undefined" != typeof globalThis ? globalThis : t || self)["chartjs-chart-treemap"] = {}, t.Chart, t.Chart.helpers)
}(this, (function(t, e, n) {
    "use strict";
    const i = (t, e) => e > t || t.length > e.length && t.slice(0, e.length) === e,
        r = t => "" + t;

    function o(t, e, i, s = [], a = 0, h = []) {
        const l = a - 1;
        if (t[0] in i && a > 0) {
            const n = s.reduce((function(t, e, n) {
                return n !== l && (t[r(n)] = e), t
            }), {});
            n[e] = s[l], t.forEach((function(t) {
                n[t] = i[t]
            })), h.push(n)
        } else
            for (const r of Object.keys(i)) {
                const l = i[r];
                n.isObject(l) && (s.push(r), o(t, e, l, s, a + 1, h))
            }
        return s.splice(l, 1), h
    }

    function s(t, e, n) {
        const i = o(t, e, n);
        if (!i.length) return i;
        const s = i.reduce((function(t, e) {
            const n = Object.keys(e).length - 2;
            return t > n ? t : n
        }));
        return i.forEach((function(t) {
            for (let e = 0; e < s; e++) {
                const n = r(e);
                t[n] || (t[n] = "")
            }
        })), i
    }

    function a(t) {
        const e = [...t],
            n = [];
        for (; e.length;) {
            const t = e.pop();
            Array.isArray(t) ? e.push(...t) : n.push(t)
        }
        return n.reverse()
    }

    function h(t, e, n) {
        if (!t.length) return;
        const i = [];
        for (const r of t) {
            const t = e[r];
            if ("" === t) {
                i.push(n);
                break
            }
            i.push(t)
        }
        return i.length ? i.join(".") : n
    }

    function l(t, e, n, i, r, o, s = []) {
        const a = n[0],
            l = n.slice(1),
            c = Object.create(null),
            u = Object.create(null),
            f = [];
        let d, g, p;
        for (g = 0, p = t.length; g < p; ++g) {
            const n = t[g];
            if (r && n[r] !== o) continue;
            if (d = n[e] || n[i] || "", !(d in c)) {
                const t = c[d] = {
                    value: 0
                };
                l.forEach((function(e) {
                    t[e] = 0
                })), u[d] = []
            }
            c[d].value += +n[a], c[d].label = n[e] || "";
            const f = c[d];
            l.forEach((function(t) {
                f[t] += n[t]
            })), c[d].path = h(s, n, d), u[d].push(n)
        }
        return Object.keys(c).forEach((t => {
            const n = {
                children: u[t]
            };
            n[a] = +c[t].value, l.forEach((function(e) {
                n[e] = +c[t][e]
            })), n[e] = c[t].label, n.label = t, n.path = c[t].path, r && (n[r] = o), f.push(n)
        })), f
    }

    function c(t, e) {
        let i, r = t.length;
        if (!r) return e;
        const o = n.isObject(t[0]);
        for (e = o ? e : "v", i = 0, r = t.length; i < r; ++i) o ? t[i]._idx = i : t[i] = {
            v: t[i],
            _idx: i
        };
        return e
    }

    function u(t, e) {
        e ? t.sort(((t, n) => +n[e] - +t[e])) : t.sort(((t, e) => +e - +t))
    }

    function f(t, e) {
        let n, i, r;
        for (n = 0, i = 0, r = t.length; i < r; ++i) n += e ? +t[i][e] : +t[i];
        return n
    }

    function d(t, e, n, r = !0) {
        const o = n.split(".");
        let s = 0;
        for (const a of e.split(".")) {
            const h = o[s++];
            if (parseInt(a, 10) < parseInt(h, 10)) break;
            if (i(h, a)) {
                if (r) throw new Error(`${t} v${n} is not supported. v${e} or newer is required.`);
                return !1
            }
        }
        return !0
    }
    const g = new Map;

    function p(t, e) {
        const {
            x: n,
            y: i,
            width: r,
            height: o
        } = t.getProps(["x", "y", "width", "height"], e);
        return {
            left: n,
            top: i,
            right: n + r,
            bottom: i + o
        }
    }

    function m(t, e, n) {
        return Math.max(Math.min(t, n), e)
    }

    function x(t, e, i) {
        const r = n.toTRBL(t);
        return {
            t: m(r.top, 0, i),
            r: m(r.right, 0, e),
            b: m(r.bottom, 0, i),
            l: m(r.left, 0, e)
        }
    }

    function b(t) {
        const e = p(t),
            i = e.right - e.left,
            r = e.bottom - e.top,
            o = x(t.options.borderWidth, i / 2, r / 2),
            s = function(t, e, i) {
                const r = n.toTRBLCorners(t),
                    o = Math.min(e, i);
                return {
                    topLeft: m(r.topLeft, 0, o),
                    topRight: m(r.topRight, 0, o),
                    bottomLeft: m(r.bottomLeft, 0, o),
                    bottomRight: m(r.bottomRight, 0, o)
                }
            }(t.options.borderRadius, i / 2, r / 2),
            a = {
                x: e.left,
                y: e.top,
                w: i,
                h: r,
                active: t.active,
                radius: s
            };
        return {
            outer: a,
            inner: {
                x: a.x + o.l,
                y: a.y + o.t,
                w: a.w - o.l - o.r,
                h: a.h - o.t - o.b,
                active: t.active,
                radius: {
                    topLeft: Math.max(0, s.topLeft - Math.max(o.t, o.l)),
                    topRight: Math.max(0, s.topRight - Math.max(o.t, o.r)),
                    bottomLeft: Math.max(0, s.bottomLeft - Math.max(o.b, o.l)),
                    bottomRight: Math.max(0, s.bottomRight - Math.max(o.b, o.r))
                }
            }
        }
    }

    function y(t, e, n, i) {
        const r = null === e,
            o = null === n,
            s = !(!t || r && o) && p(t, i);
        return s && (r || e >= s.left && e <= s.right) && (o || n >= s.top && n <= s.bottom)
    }

    function v(t, e) {
        t.rect(e.x, e.y, e.w, e.h)
    }

    function w(t, e) {
        if (!e || !1 === e.display) return !1;
        const {
            w: i,
            h: r
        } = t, o = n.toFont(e.font).lineHeight, s = m(2 * n.valueOrDefault(e.padding, 3), 0, Math.min(i, r));
        return i - s > o && r - s > o
    }

    function _(t, e, i, r, o) {
        const {
            captions: s,
            labels: a
        } = i;
        t.save(), t.beginPath(), t.rect(e.x, e.y, e.w, e.h), t.clip();
        const h = r && (!n.defined(r.l) || r.l === o);
        h && a.display ? function(t, e, i) {
            const r = i.labels,
                o = r.formatter;
            if (!o) return;
            const s = n.isArray(o) ? o : [o];
            let a = function(t, e) {
                    const {
                        font: i,
                        hoverFont: r
                    } = e, o = (t.active ? r : i) || i;
                    return n.isArray(o) ? o.map((t => n.toFont(t))) : [n.toFont(o)]
                }(e, r),
                h = function(t, e, n) {
                    const i = n.reduce((function(t, e) {
                            return t += e.string
                        }), ""),
                        r = e.join() + i + (t._measureText ? "-spriting" : "");
                    if (!g.has(r)) {
                        t.save();
                        const i = e.length;
                        let o = 0,
                            s = 0;
                        for (let r = 0; r < i; r++) {
                            const i = n[Math.min(r, n.length - 1)];
                            t.font = i.string;
                            const a = e[r];
                            o = Math.max(o, t.measureText(a).width), s += i.lineHeight
                        }
                        t.restore(), g.set(r, {
                            width: o,
                            height: s
                        })
                    }
                    return g.get(r)
                }(t, s, a);
            const l = function(t, e, n, i) {
                const {
                    overflow: r,
                    padding: o
                } = n, {
                    width: s,
                    height: a
                } = i;
                if ("hidden" === r) return !(s + 2 * o > e.w || a + 2 * o > e.h);
                if ("fit" === r) {
                    const t = Math.min(e.w / (s + 2 * o), e.h / (a + 2 * o));
                    if (t < 1) return t
                }
                return !0
            }(0, e, r, h);
            if (!l) return;
            n.isNumber(l) && (h = {
                width: h.width * l,
                height: h.height * l
            }, a = function(t, e) {
                return t.map((function(t) {
                    return t.size = Math.floor(t.size * e), t.lineHeight = void 0, n.toFont(t)
                }))
            }(a, l));
            const {
                color: c,
                hoverColor: u,
                align: f
            } = r, d = (e.active ? u : c) || c, p = n.isArray(d) ? d : [d], m = function(t, e, n) {
                const {
                    align: i,
                    position: r,
                    padding: o
                } = e;
                let s, a;
                s = M(t, i, o), a = "top" === r ? t.y + o : "bottom" === r ? t.y + t.h - o - n.height : t.y + (t.h - n.height) / 2 + o;
                return {
                    x: s,
                    y: a
                }
            }(e, r, h);
            t.textAlign = f, t.textBaseline = "middle";
            let x = 0;
            s.forEach((function(e, n) {
                const i = p[Math.min(n, p.length - 1)],
                    r = a[Math.min(n, a.length - 1)],
                    o = r.lineHeight;
                t.font = r.string, t.fillStyle = i, t.fillText(e, m.x, m.y + o / 2 + x), x += o
            }))
        }(t, e, i) : !h && w(e, s) && function(t, e, i, r) {
            const {
                captions: o,
                spacing: s,
                rtl: a
            } = i, {
                color: h,
                hoverColor: l,
                font: c,
                hoverFont: u,
                padding: f,
                align: d,
                formatter: g
            } = o, p = (e.active ? l : h) || h, m = d || (a ? "right" : "left"), x = (e.active ? u : c) || c, b = n.toFont(x), y = b.lineHeight / 2, v = M(e, m, f);
            t.fillStyle = p, t.font = b.string, t.textAlign = m, t.textBaseline = "middle", t.fillText(g || r.g, v, e.y + f + s + y)
        }(t, e, i, r), t.restore()
    }

    function M(t, e, n) {
        return "left" === e ? t.x + n : "right" === e ? t.x + t.w - n : t.x + t.w / 2
    }
    class C extends e.Element {
        constructor(t) {
            super(), this.options = void 0, this.width = void 0, this.height = void 0, t && Object.assign(this, t)
        }
        draw(t, e, i = 0) {
            if (!e) return;
            const r = this.options,
                {
                    inner: o,
                    outer: s
                } = b(this),
                a = (h = s.radius).topLeft || h.topRight || h.bottomLeft || h.bottomRight ? n.addRoundedRectPath : v;
            var h;
            t.save(), s.w === o.w && s.h === o.h || (t.beginPath(), a(t, s), t.clip(), a(t, o), t.fillStyle = r.borderColor, t.fill("evenodd")), t.beginPath(), a(t, o), t.fillStyle = r.backgroundColor, t.fill(),
                function(t, e, n, i) {
                    const r = n.dividers;
                    if (!r.display || !i._data.children.length) return;
                    const {
                        x: o,
                        y: s,
                        w: a,
                        h: h
                    } = e, {
                        lineColor: l,
                        lineCapStyle: c,
                        lineDash: u,
                        lineDashOffset: f,
                        lineWidth: d
                    } = r;
                    if (t.save(), t.strokeStyle = l, t.lineCap = c, t.setLineDash(u), t.lineDashOffset = f, t.lineWidth = d, t.beginPath(), a > h) {
                        const e = a / 2;
                        t.moveTo(o + e, s), t.lineTo(o + e, s + h)
                    } else {
                        const e = h / 2;
                        t.moveTo(o, s + e), t.lineTo(o + a, s + e)
                    }
                    t.stroke(), t.restore()
                }(t, o, r, e), _(t, o, r, e, i), t.restore()
        }
        inRange(t, e, n) {
            return y(this, t, e, n)
        }
        inXRange(t, e) {
            return y(this, t, null, e)
        }
        inYRange(t, e) {
            return y(this, null, t, e)
        }
        getCenterPoint(t) {
            const {
                x: e,
                y: n,
                width: i,
                height: r
            } = this.getProps(["x", "y", "width", "height"], t);
            return {
                x: e + i / 2,
                y: n + r / 2
            }
        }
        tooltipPosition() {
            return this.getCenterPoint()
        }
        getRange(t) {
            return "x" === t ? this.width / 2 : this.height / 2
        }
    }

    function k(t, e, n, i) {
        const r = t._normalized,
            o = e * r / n,
            s = Math.sqrt(r * o),
            a = r / s;
        return {
            d1: s,
            d2: a,
            w: "_ix" === i ? s : a,
            h: "_ix" === i ? a : s
        }
    }
    C.id = "treemap", C.defaults = {
        label: void 0,
        borderRadius: 0,
        borderWidth: 0,
        captions: {
            align: void 0,
            color: "black",
            display: !0,
            font: {},
            formatter: t => t.raw.g || t.raw._data.label || "",
            padding: 3
        },
        dividers: {
            display: !1,
            lineCapStyle: "butt",
            lineColor: "black",
            lineDash: [],
            lineDashOffset: 0,
            lineWidth: 1
        },
        labels: {
            align: "center",
            color: "black",
            display: !1,
            font: {},
            formatter: t => t.raw.g ? [t.raw.g, t.raw.v + ""] : t.raw._data.label ? [t.raw._data.label, t.raw.v + ""] : t.raw.v + "",
            overflow: "cut",
            position: "middle",
            padding: 3
        },
        rtl: !1,
        spacing: .5
    }, C.descriptors = {
        labels: {
            _fallback: !0
        },
        captions: {
            _fallback: !0
        },
        _scriptable: !0,
        _indexable: !1
    }, C.defaultRoutes = {
        backgroundColor: "backgroundColor",
        borderColor: "borderColor"
    };
    const R = (t, e) => t.rtl ? t.x + t.iw - e : t.x + t._ix;

    function O(t, e, n, i) {
        const r = {
            x: R(t, n.w),
            y: t.y + t._iy,
            w: n.w,
            h: n.h,
            a: e._normalized,
            v: e.value,
            vs: e.values,
            s: i,
            _data: e._data
        };
        return e.group && (r.g = e.group, r.l = e.level, r.gs = e.groupSum), r
    }
    class j {
        constructor(t) {
            t = t || {
                w: 1,
                h: 1
            }, this.rtl = !!t.rtl, this.x = t.x || t.left || 0, this.y = t.y || t.top || 0, this._ix = 0, this._iy = 0, this.w = t.w || t.width || t.right - t.left, this.h = t.h || t.height || t.bottom - t.top
        }
        get area() {
            return this.w * this.h
        }
        get iw() {
            return this.w - this._ix
        }
        get ih() {
            return this.h - this._iy
        }
        get dir() {
            const t = this.ih;
            return t <= this.iw && t > 0 ? "y" : "x"
        }
        get side() {
            return "x" === this.dir ? this.iw : this.ih
        }
        map(t) {
            const {
                dir: e,
                side: n
            } = this, i = "x" === e ? "_ix" : "_iy", r = t.nsum, o = t.get(), s = n * n, a = r * r, h = [];
            let l = 0,
                c = 0;
            for (const e of o) {
                const n = k(e, s, a, i);
                c += n.d1, l = Math.max(l, n.d2), h.push(O(this, e, n, t.sum)), this[i] += n.d1
            }
            return this["x" === e ? "_iy" : "_ix"] += l, this[i] -= c, h
        }
    }
    const T = Math.min,
        E = Math.max;

    function P(t, e) {
        const n = +e[t.key],
            i = n * t.ratio;
        return e._normalized = i, {
            min: T(t.min, n),
            max: E(t.max, n),
            sum: t.sum + n,
            nmin: T(t.nmin, i),
            nmax: E(t.nmax, i),
            nsum: t.nsum + i
        }
    }

    function S(t, e, n) {
        t._arr.push(e),
            function(t, e) {
                Object.assign(t, e)
            }(t, n)
    }
    class D {
        constructor(t, e) {
            const n = this;
            n.key = t, n.ratio = e, n.reset()
        }
        get length() {
            return this._arr.length
        }
        reset() {
            const t = this;
            t._arr = [], t._hist = [], t.sum = 0, t.nsum = 0, t.min = 1 / 0, t.max = -1 / 0, t.nmin = 1 / 0, t.nmax = -1 / 0
        }
        push(t) {
            S(this, t, P(this, t))
        }
        pushIf(t, e, ...n) {
            const i = P(this, t);
            if (!e((r = this, {
                    min: r.min,
                    max: r.max,
                    sum: r.sum,
                    nmin: r.nmin,
                    nmax: r.nmax,
                    nsum: r.nsum
                }), i, n)) return t;
            var r;
            S(this, t, i)
        }
        get() {
            return this._arr
        }
    }

    function L(t, e, n) {
        if (0 === t.sum) return !0;
        const [i] = n, r = t.nsum * t.nsum, o = e.nsum * e.nsum, s = i * i, a = Math.max(s * t.nmax / r, r / (s * t.nmin));
        return Math.max(s * e.nmax / o, o / (s * e.nmin)) <= a
    }

    function F(t, e, n = [], i, r, o) {
        t = t || [];
        const s = [],
            h = new j(e),
            l = new D("value", h.area / f(t, n[0]));
        let d = h.side;
        const g = t.length;
        let p, m;
        if (!g) return s;
        const x = t.slice();
        let b = c(x, n[0]);
        u(x, b);
        const y = t => i && x[t][i];
        for (p = 0; p < g; ++p) {
            if (m = {
                    value: (v = p, b ? +x[v][b] : +x[v]),
                    groupSum: o,
                    _data: t[x[p]._idx],
                    level: void 0,
                    group: void 0
                }, i) {
                m.level = r, m.group = y(p);
                const t = x[p];
                m.values = n.reduce((function(e, n) {
                    return e[n] = +t[n], e
                }), {})
            }
            m = l.pushIf(m, L, d), m && (s.push(h.map(l)), d = h.side, l.reset(), l.push(m))
        }
        var v;
        return l.length && s.push(h.map(l)), a(s)
    }

    function A(t, e, n, i) {
        const r = 2 * i,
            o = e.getPixelForValue(t.x),
            s = n.getPixelForValue(t.y),
            a = e.getPixelForValue(t.x + t.w) - o,
            h = n.getPixelForValue(t.y + t.h) - s;
        return {
            x: o + i,
            y: s + i,
            width: a - r,
            height: h - r,
            hidden: r > a || r > h
        }
    }

    function z(t, e) {
        let n, i;
        if (!t || !e) return !0;
        if (t === e) return !1;
        if (t.length !== e.length) return !0;
        for (n = 0, i = t.length; n < i; ++n)
            if (t[n] !== e[n]) return !0;
        return !1
    }
    class H extends e.DatasetController {
        constructor(t, e) {
            super(t, e), this._groups = void 0, this._keys = void 0, this._rect = void 0, this._rectChanged = !0
        }
        initialize() {
            this.enableOptionSharing = !0, super.initialize()
        }
        getMinMax(t) {
            return {
                min: 0,
                max: "x" === t.axis ? t.right - t.left : t.bottom - t.top
            }
        }
        configure() {
            super.configure();
            const {
                xScale: t,
                yScale: e
            } = this.getMeta();
            if (!t || !e) return;
            const n = t.right - t.left,
                i = e.bottom - e.top,
                r = {
                    x: 0,
                    y: 0,
                    w: n,
                    h: i,
                    rtl: !!this.options.rtl
                };
            var o, s;
            o = this._rect, s = r, o && s && o.x === s.x && o.y === s.y && o.w === s.w && o.h === s.h && o.rtl === s.rtl || (this._rect = r, this._rectChanged = !0), this._rectChanged && (t.max = n, t.configure(), e.max = i, e.configure())
        }
        update(t) {
            const e = this.getDataset(),
                {
                    data: i
                } = this.getMeta(),
                o = e.groups || [],
                a = [e.key || ""].concat(e.sumKeys || []),
                h = e.tree = e.tree || e.data || [];
            "reset" === t && this.configure(), (this._rectChanged || z(this._keys, a) || z(this._groups, o) || this._prevTree !== h) && (this._groups = o.slice(), this._keys = a.slice(), this._prevTree = h, this._rectChanged = !1, e.data = function(t, e, i, o) {
                const a = e.treeLeafKey || "_leaf";
                n.isObject(t) && (t = s(i, a, t));
                const h = e.groups || [],
                    c = h.length,
                    u = n.valueOrDefault(e.spacing, 0),
                    f = e.captions || {},
                    d = n.toFont(f.font),
                    g = n.valueOrDefault(f.padding, 3);
                return c ? function n(o, s, p, m) {
                    const b = r(h[o]),
                        y = o > 0 && r(h[o - 1]),
                        v = l(t, b, i, a, y, p, h.filter(((t, e) => e <= o))),
                        _ = F(v, s, i, b, o, m),
                        M = _.slice();
                    return o < c - 1 && _.forEach((t => {
                        const i = x(e.borderWidth, t.w / 2, t.h / 2),
                            r = {
                                ...s,
                                x: t.x + u + i.l,
                                y: t.y + u + i.t,
                                w: t.w - 2 * u - i.l - i.r,
                                h: t.h - 2 * u - i.t - i.b
                            };
                        w(r, f) && (r.y += d.lineHeight + 2 * g, r.h -= d.lineHeight + 2 * g), M.push(...n(o + 1, r, t.g, t.s))
                    })), M
                }(0, o) : F(t, o, i)
            }(h, e, this._keys, this._rect), this._dataCheck(), this._resyncElements()), this.updateElements(i, 0, i.length, t)
        }
        updateElements(t, e, n, i) {
            const r = "reset" === i,
                o = this.getDataset(),
                s = this._rect.options = this.resolveDataElementOptions(e, i),
                a = this.getSharedOptions(s),
                h = this.includeOptions(i, a),
                {
                    xScale: l,
                    yScale: c
                } = this.getMeta(this.index);
            for (let s = e; s < e + n; s++) {
                const e = a || this.resolveDataElementOptions(s, i),
                    n = A(o.data[s], l, c, e.spacing);
                r && (n.width = 0, n.height = 0), h && (n.options = e), this.updateElement(t[s], s, n, i)
            }
            this.updateSharedOptions(a, i, s)
        }
        draw() {
            const {
                ctx: t,
                chartArea: e
            } = this.chart, i = this.getMeta().data || [], r = this.getDataset(), o = (r.groups || []).length - 1, s = r.data;
            n.clipArea(t, e);
            for (let e = 0, n = i.length; e < n; ++e) {
                const n = i[e];
                n.hidden || n.draw(t, s[e], o)
            }
            n.unclipArea(t)
        }
    }
    H.id = "treemap", H.version = "2.3.0", H.defaults = {
        dataElementType: "treemap",
        animations: {
            numbers: {
                type: "number",
                properties: ["x", "y", "width", "height"]
            }
        }
    }, H.descriptors = {
        _scriptable: !0,
        _indexable: !1
    }, H.overrides = {
        interaction: {
            mode: "point",
            includeInvisible: !0,
            intersect: !0
        },
        hover: {},
        plugins: {
            tooltip: {
                position: "treemap",
                intersect: !0,
                callbacks: {
                    title(t) {
                        if (t.length) {
                            return t[0].dataset.key || ""
                        }
                        return ""
                    },
                    label(t) {
                        const e = t.dataset,
                            n = e.data[t.dataIndex],
                            i = n.g || n._data.label || e.label;
                        return (i ? i + ": " : "") + n.v
                    }
                }
            }
        },
        scales: {
            x: {
                type: "linear",
                alignToPixels: !0,
                bounds: "data",
                display: !1
            },
            y: {
                type: "linear",
                alignToPixels: !0,
                bounds: "data",
                display: !1,
                reverse: !0
            }
        }
    }, H.beforeRegister = function() {
        d("chart.js", "3.8", e.Chart.version)
    }, H.afterRegister = function() {
        const t = e.registry.plugins.get("tooltip");
        t ? t.positioners.treemap = function(t) {
            if (!t.length) return !1;
            return t[t.length - 1].element.tooltipPosition()
        } : console.warn("Unable to register the treemap positioner because tooltip plugin is not registered")
    }, H.afterUnregister = function() {
        const t = e.registry.plugins.get("tooltip");
        t && delete t.positioners.treemap
    }, e.Chart.register(H, C), t.flatten = a, t.getGroupKey = r, t.group = l, t.index = c, t.normalizeTreeToArray = s, t.requireVersion = d, t.sort = u, t.sum = f
}));
//# sourceMappingURL=chartjs-chart-treemap.min.js.map
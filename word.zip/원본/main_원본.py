import pandas as pd
import requests
import re
import os
from bs4 import BeautifulSoup
from google import genai
from openai import OpenAI

# 1. API 키 및 클라이언트 설정
GEMINI_KEY = "AIzaSyD3oKERtLmCXOPHOj1gILavTs4b1rhYu8I"
GPT_KEY = "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"

client_gemini = genai.Client(api_key=GEMINI_KEY)
client_gpt = OpenAI(api_key=GPT_KEY)

# 2. 용어 리스트
list_word = ["BGP", "ISP", "DNS", "TCP/IP", "IXP", "CDN", "DHCP", "인공지능"] 

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"}

def get_tta_data(word):
    url = f"https://terms.tta.or.kr/dictionary/dictionaryView.do?subject={word}"
    try:
        res = requests.get(url, headers=HEADERS, timeout=5)
        soup = BeautifulSoup(res.text, "html.parser")
        target = soup.select_one("div.no_css")
        return " ".join(target.get_text(separator=" ", strip=True).split()) if target else ""
    except: return ""

def get_naver_full_data(word):
    search_url = f"https://terms.naver.com/search.naver?query={word}&dicType=14&cid=42343"
    try:
        res = requests.get(search_url, headers=HEADERS, timeout=5)
        soup = BeautifulSoup(res.text, "html.parser")
        items = soup.select(".search_result_area .content_list > li")
        if not items: return ""
        target_item = items[0]
        it_keywords = ["정보통신", "컴퓨터", "인터넷", "통신", "데이터", "IT", "네트워크"]
        for item in items:
            if any(k in item.get_text() for k in it_keywords):
                target_item = item
                break
        detail_url = "https://terms.naver.com" + target_item.select_one(".title a")['href']
        d_res = requests.get(detail_url, headers=HEADERS, timeout=5)
        d_soup = BeautifulSoup(d_res.text, "html.parser")
        content_area = d_soup.select_one("#size_ct")
        return content_area.get_text(separator="\n", strip=True) if content_area else ""
    except: return ""

def get_itwiki_data(word):
    url = f"https://itwiki.kr/w/{word}"
    try:
        res = requests.get(url, headers=HEADERS, timeout=5)
        if res.status_code != 200: return ""
        soup = BeautifulSoup(res.text, "html.parser")
        content_area = soup.select_one(".mw-parser-output")
        if content_area:
            for toc in content_area.select(".toc"): toc.decompose()
            for edit in content_area.select(".mw-editsection"): edit.decompose()
            return content_area.get_text(separator="\n", strip=True)
        return ""
    except: return ""

def run_total_automation():
    final_results = []
    output_file = "IT용어_엑셀.xlsx"
    print(f"🚀 총 {len(list_word)}개 용어 작업 시작 (실시간 저장 모드)")

    for idx, word in enumerate(list_word, start=1):
        print(f"\n[{idx}/{len(list_word)}] '{word}' 수집 중...")
        
        # 크롤링
        tta_def = get_tta_data(word)
        naver_def = get_naver_full_data(word)
        itwiki_def = get_itwiki_data(word)
        print(f" ✅ 크롤링 완료 (TTA, 네이버백과, IT위키)")

        prompt = f"IT 용어 사전용: '{word}'의 기술적 정의와 핵심 원리를 전문가 수준으로 정리해줘."
        
        # Gemini (기존 스타일 출력 복구)
        try:
            gem_res = client_gemini.models.generate_content(model="models/gemini-3-pro-preview", contents=prompt)
            gem_ans = gem_res.text.strip()
            print(" ✅ Gemini 분석 완료")
        except Exception as e: 
            gem_ans = f"Error: {e}"
            print(" ❌ Gemini 에러")

        # GPT (기존 스타일 출력 복구)
        try:
            gpt_res = client_gpt.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": prompt}])
            gpt_ans = gpt_res.choices[0].message.content.strip()
            print(" ✅ GPT 분석 완료")
        except Exception as e: 
            gpt_ans = f"Error: {e}"
            print(" ❌ GPT 에러")

        final_results.append({
            "용어": word,
            "수동정의(빈칸)": "", 
            "TTA 표준정의": tta_def,
            "네이버 상세본문": naver_def,
            "IT위키 상세본문": itwiki_def,
            "제미나이 답변": gem_ans,
            "지피티 답변": gpt_ans
        })

        # [실시간 저장] 매 회마다 엑셀 갱신 (중간에 꺼져도 안전)
        df_temp = pd.DataFrame(final_results)
        df_temp.to_excel(output_file, index=False)

    print(f"\n✨ 대장정 종료! '{output_file}' 파일이 최종 완성되었습니다.")

if __name__ == "__main__":
    run_total_automation()

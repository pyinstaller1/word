import pyperclip
import pandas as pd



with open('original.txt', 'r', encoding='utf-8') as f:
    original = f.read()

original = original.replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n')
original = original.replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n').replace('\n\n', '\n')

# print(repr(original))

# orininal.txt 의 용어 뜻을 엑셀의 용어 뜻 칸에 입력

# original: txt 파일 => dict_original
# str_new: 엑셀





list_original = original.split('#')
dict_original = {}
for item in list_original:
    dict_original[item.split('(')[0].strip()] = ")".join(item.split(')')[1:]).strip()





df = pd.read_excel('IT용어_엑셀.xlsx')
header = "\t".join(df.columns)
rows = []
for _, row in df.iterrows():
    clean_row = [str(val).replace('\r', '') for val in row]
    rows.append("\t".join(clean_row))
text = header + "\r\n" + "\r\n".join(rows)




list_new = []
for i in range(len(text.split('\r\n'))):
    list_temp = []

    for j in range(len(text.split('\r\n')[i].split('\t'))):
        if i > 0 and j == 1:   # 1번 열은 original.txt 의 기본 용어 뜻
            if not original.split('#')[i].split('\n') or len(original.split('#')[i].split('\n')) < 3:
                break
            if text.split('\r\n')[i].split('\t')[0].strip() in ['To-be', '가용성', '클라이언트/서버']:
                list_temp = []
                break
            
            val = dict_original[text.split('\r\n')[i].split('\t')[0].strip()]   # original_text 의 기본 뜻 저장            
            list_temp.append(f'"{val.replace('"', '""')}"')
        else: # 1번 이외 열은 AI 분석
            val = text.split('\r\n')[i].split('\t')[j]
            list_temp.append(f'"{val.replace('"', '""')}"')
    str_temp = '\t'.join(list_temp)
    list_new.append(str_temp)


str_new = ""
str_new += '\r\n'.join(list_new)
str_new = str_new

pyperclip.copy(str_new)
print('클립보드에 저장되었습니다.\nIT용어_엑셀.xlsx 에 붙여넣기 하세요')












